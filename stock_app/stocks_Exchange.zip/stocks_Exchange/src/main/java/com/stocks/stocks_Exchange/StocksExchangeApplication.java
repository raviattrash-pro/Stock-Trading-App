package com.stocks.stocks_Exchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StocksExchangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(StocksExchangeApplication.class, args);
	}

}
