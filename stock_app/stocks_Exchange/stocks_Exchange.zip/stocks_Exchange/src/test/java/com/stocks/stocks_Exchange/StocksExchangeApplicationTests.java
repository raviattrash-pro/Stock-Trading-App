package com.stocks.stocks_Exchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StocksExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
